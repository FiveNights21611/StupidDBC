
package net.mcreator.stupiddragonblockc.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.stupiddragonblockc.entity.KingKaiEntity;

public class KingKaiRenderer extends HumanoidMobRenderer<KingKaiEntity, HumanoidModel<KingKaiEntity>> {
	public KingKaiRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR))));
	}

	@Override
	public ResourceLocation getTextureLocation(KingKaiEntity entity) {
		return new ResourceLocation("stupid_dbc:textures/entities/2020_07_17_king-kai-derp-14844566.png");
	}
}
